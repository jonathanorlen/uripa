		<div id="footer" >
			<div style="display:none">
				<div>
					<h1>Place Holder</h1>
					<ul>
						<li>
							<a href="index.html">This is just a place holder</a>
						</li>
						<li>
							<a href="index.html">This is just a place holder</a>
						</li>
						<li>
							<a href="index.html">This is just a place holder</a>
						</li>
					</ul>
				</div>
				<div>
					<h1>Place Holder</h1>
					<ul>
						<li>
							<a href="index.html">This is just a place holder</a>
						</li>
						<li>
							<a href="index.html">This is just a place holder</a>
						</li>
						<li>
							<a href="index.html">This is just a place holder</a>
						</li>
					</ul>
				</div>
				<div>
					<h1>Place Holder</h1>
					<ul>
						<li>
							<a href="index.html">This is just a place holder</a>
						</li>
						<li>
							<a href="index.html">This is just a place holder</a>
						</li>
						<li>
							<a href="index.html">This is just a place holder</a>
						</li>
					</ul>
				</div>
				<div>
					<h1>Connect</h1>
					<a href="http://www.freewebsitetemplates.com/misc/contact" target="_blank" id="mail">Email us</a>
					<a href="http://freewebsitetemplates.com/go/facebook/" target="_blank" id="facebook">Facebook</a>
					<a href="http://freewebsitetemplates.com/go/twitter/" target="_blank" id="twitter">Twitter</a>
					<a href="http://freewebsitetemplates.com/go/googleplus/" target="_blank" id="googleplus">Google&#43;</a>
				</div>
			</div>
            <p> 
				Cloud Astro &copy; 2016
			</p>
			
		</div>
	</div>
</body>
</html>

<script type="text/javascript" src="<?php echo base_url() . 'component/web/nivo-slider/demo/scripts/jquery-1.9.0.min.js '?>"></script>
<script type="text/javascript" src="<?php echo base_url() . 'component/web/nivo-slider/jquery.nivo.slider.js '?>"></script>
<script type="text/javascript">
    $(window).load(function() {
    	$('#slider').nivoSlider();
    });
    </script>
