<div id="page">
	<a style="
	background: rgb(160, 12, 239);
	color: #ffffff;
	right: 0;
	position: fixed;
	padding: 15px;
	letter-spacing: 0em;
	text-align: center;
	text-decoration: none;
	font-weight: bolder;
	" href="http://uripasistem.cloud-astro.com" class="btn" target="_blank">Login</a>
	<div id="header">
		<center></center><a href="<?php echo base_url(). 'web/dasboard/' ?>" id="logo"><img style="height: auto; weight:auto;" src="<?php echo base_url() . 'component/web/images/logo_utama.jpg '?>" alt="Logo"/></a></center>
		<ul>
			<li >
				<a href="<?php echo base_url() ?>" class="<?php if(@$aktif == 'dashboard'){ echo 'aktif';} ?>">Home</a>
			</li>
			<li>
				<a href="<?php echo base_url() . 'web/profile' ?>" class="<?php if(@$aktif == 'profile'){ echo 'aktif';} ?>">About us</a>

			</li>

			<li>
				<a href="<?php echo base_url() . 'web/product' ?>" class="<?php if(@$aktif == 'product'){ echo 'aktif';} ?>">Our Services</a>
			</li>

			<li>
				<a href="<?php echo base_url() . 'web/paket' ?>" class="<?php if(@$aktif == 'paket'){ echo 'aktif';} ?>">Paket</a>
			</li>



			<li>
				<a href="<?php echo base_url() . 'web/home_galery' ?>" class="<?php if(@$aktif == 'galery'){ echo 'aktif';} ?>">Our Gallery</a>
			</li>

			<li>
				<a href="<?php echo base_url() . 'web/home_news' ?>" class="<?php if(@$aktif == 'news'){ echo 'aktif';} ?>">News</a>
			</li>
			<li>
				<a href="<?php echo base_url() . 'web/contact' ?>" class="<?php if(@$aktif == 'contact'){ echo 'aktif';} ?>">Contact</a>
			</li>



		</ul>



	</div>
