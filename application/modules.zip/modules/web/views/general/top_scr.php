<!DOCTYPE html>
<!-- Website template by freewebsitetemplates.com -->
	<link rel="stylesheet" href="<?php echo base_url() . 'component/web/nivo-slider/themes/default/default.css '?>" type="text/css" media="screen" />
    <link rel="stylesheet" href="<?php echo base_url() . 'component/web/nivo-slider/themes/light/light.css '?>" type="text/css" media="screen" />
    <link rel="stylesheet" href="<?php echo base_url() . 'component/web/nivo-slider/themes/dark/dark.css '?>" type="text/css" media="screen" />
    <link rel="stylesheet" href="<?php echo base_url() . 'component/web/nivo-slider/themes/bar/bar.css '?>" type="text/css" media="screen" />
    <link rel="stylesheet" href="<?php echo base_url() . 'component/web/nivo-slider/nivo-slider.css '?>" type="text/css" media="screen" />
    <!-- <link href="<?php echo base_url() . 'component/admin/bootstrap/css/bootstrap.min.css '?>" rel="stylesheet" type="text/css" /> -->

<html>
<head>
	<meta charset="UTF-8">
	<title>Uripa : Tour & Travel</title>
	<link rel="icon" type="image/png" href="<?php echo base_url() . 'component/web/images/uripa.png '?>">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url() . 'component/web/css/style.css '?>">

</head>
<body>