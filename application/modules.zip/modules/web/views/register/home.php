<style type="text/css" media="screen">
	.read
	{
		color:#FFF;
		text-decoration: none;
	}
	.read:hover
	{
		color:#afafab;
		text-decoration: none;
	}
</style>
<div id="body"><br><br><br><br><br>
			<div id="content">
			
				<div class="title" style="    background-color: #a00cef;
    color: rgb(239, 49, 37) !important;
    padding: 10px;
    padding-top: 20px;
    text-align: left;font-size: 1.3em;
    font-weight: bold;">Register</div>
    <div class="konten" style="padding: 20px;">
				 <table class="table" width="100%" border="2">
				 	<tr>
				 		<td align="center" width="30%" rowspan="2"><img src="<?php echo base_url().'component/web/images/uripa.png' ?>"></td>
				 		<td align="center" style="font-size: 40px;font-style: bold;">PT. URIPA</td>
				 	</tr>
				 	<tr>
				 		<td align="center" style="font-size: 20px;font-style: bold;">(USAHA MANDIRI PALSAPAD)</td>
				 		
				 	</tr>
				 	<tr>
				 		<td style="background-color: black;color: white "></td>
				 	</tr>
				 </table>
			</div>
			</div>
		</div>